#boxplot using the ggplot
install.packages("ggplot")
library(ggplot) # need to install for the ggplot function
install.packages("reshape2")
library(reshape2) # need to install and library for the melt function

#looping for 10 year
for (i in 1:10) 
{
  #initial year is 2004
  a = 2004; 
  
  # assigning to Y2005, Y2006 and so forth
  assign(paste('Y', a+i, sep=''), HCHO_Monthly[85:127,39:57,i,])
  
}
#column binding
yall = cbind(Y2005,Y2006,Y2007,Y2008,Y2009,Y2010,Y2011,Y2012,Y2013,Y2014)

#melting to get values in only one column
long <- melt(yall)

#assigning the column name
colnames(long) <- c("sn","year","hcho.values")

#finally doing the ggplot
p <- ggplot(long, aes(x=year, y=hcho.values, fill=year)) + 
geom_boxplot()+theme(legend.position="bottom", legend.box = "horizontal") +
labs(title = "Box Plot of Us-SE - HCHO concentration from 2005 - 2014", x = "Years", y = "HCHO(molec/cm^2)") +
stat_summary(fun.y = "mean", geom = "point", shape = 9, size = 1, color = "white")

#setting the path before saving
setwd("D:/R-Programming/sujanojha/test/r-codes/boxplot/")
png("boxplot.png")
print(p)
dev.off()
# END OF PROGRAM