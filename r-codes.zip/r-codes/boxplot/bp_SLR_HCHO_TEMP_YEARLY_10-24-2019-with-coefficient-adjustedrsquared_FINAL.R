dev.off()

#layout(mat = matrix(c(1,1,2,2,3,3,4,4,5,5,6,6), nrow = 3, byrow = TRUE))
par(mfrow=c(3,2))
c = 1:3
# c = 4:6 
# c = 7:9  
# c = 10:11
for ( value in c )  
{
  #simple linear regression calculation
  slr = lm(HCHO_Monthly[85:127,39:57,value,] ~ TS_Monthly[85:127,39:57,value,]) # Regressing HCHO = beta0 + beta1*TS
  #simple linear regression coefficients
  sc = summary(slr)$coefficients[2,1]
  #simple linear regression : adjusted r squared values
  ars = summary(slr)$adj.r.squared
  
  #for output in the png format
  #png(paste("HCHO_SCATTERPLOT_",value,".png"))
  
  #using the plot funtion we are plotting the 2005 - 2014
  
  first.qu1 = summary(HCHO_Monthly[85:127,39:57,value,])["1st Qu."]
  mean1 = summary(HCHO_Monthly[85:127,39:57,value,])["Mean"]
  third.qu1 = summary(HCHO_Monthly[85:127,39:57,value,])["3rd Qu."]
  
  first.qu2 = substr(summary(TS_Monthly[85:127,39:57,value,])["1st Qu."], 1,5)
  mean2 = substr(summary(TS_Monthly[85:127,39:57,value,])["Mean"],1,5)
  third.qu2 = substr(summary(TS_Monthly[85:127,39:57,value,])["3rd Qu."],1,5)

  boxplot(
    HCHO_Monthly[85:127,39:57,value,],  
    type='p',
    ylab = 'HCHo con. (molec/cm^2)'
  )
  
  legend(
    "topleft",
    legend = c(
               paste("1stQ.: ", scientific(first.qu1, digits = 3)),
               paste("Mean : ", scientific(mean1, digits = 3)),
               paste("3rdQ.: ", scientific(third.qu1, digits = 3))
    ),
    bty = 'n',
    cex = 1.5,
    ncol = 1,
    y.intersp=0.7
  )
  #in place of long if else condition
  if (value == 1) {a = 2005}
  if (value == 2) {a = 2006}
  if (value == 3) {a = 2007}
  if (value == 4) {a = 2008}
  if (value == 5) {a = 2009}
  if (value == 6) {a = 2010}
  if (value == 7) {a = 2011}
  if (value == 8) {a = 2012}
  if (value == 9) {a = 2013}
  if (value == 10) {a = 2014}
  
  title(a)
  
  boxplot(
    TS_Monthly[85:127,39:57,value,],  
    type='p',
    ylab = 'Temp. for SE US data'
  )
  
  legend(
    "topleft",
    legend = c(
      paste("1st Q: ", first.qu2),
      paste("Mean : ", mean2),
      paste("3rd Q: ", third.qu2)
    ),
    bty = 'n',
    cex = 1.5,
    ncol = 1,
    y.intersp=0.7
  )
  
  # Add regression line; can also add vertical and horizontal lines by setting 'v' and 'h'
  abline(slr)
  
  #in place of long if else condition
  if (value == 1) {a = 2005}
  if (value == 2) {a = 2006}
  if (value == 3) {a = 2007}
  if (value == 4) {a = 2008}
  if (value == 5) {a = 2009}
  if (value == 6) {a = 2010}
  if (value == 7) {a = 2011}
  if (value == 8) {a = 2012}
  if (value == 9) {a = 2013}
  if (value == 10) {a = 2014}
  
  #finally title of the plot
  title(a)
  
  #turning off the print device
  #dev.off()
}