#==========================================================
#HCHO PLOT
graphics.off()
par(mfrow = c(2,1))
for (i in 1:10) 
{
  assign(paste('Y', i, sep=''), HCHO_Monthly[85:127,39:57,i,])
}
yall = cbind(Y1,Y2,Y3,Y4,Y5,Y6,Y7,Y8,Y9,Y10)
colnames(yall) <- c("2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014")
boxplot(yall, varwidth = TRUE, xlab = "Years", ylab='HCHO(molec/cm^2)')

#TEMPERATURE PLOT
for (i in 1:10) 
{
  assign(paste('Y', i, sep=''), TS_Monthly[85:127,39:57,i,])
}
yall = cbind(Y1,Y2,Y3,Y4,Y5,Y6,Y7,Y8,Y9,Y10)
colnames(yall) <- c("2005", "2006", "2007", "2008", "2009", "2010", "2011", "2012", "2013", "2014")
boxplot(yall, varwidth = TRUE, xlab = "Years", ylab='TEMPERATURE IN K')
#==========================================================