#==========================================================
#HCHO PLOT
graphics.off()
par(mfrow = c(2,1))
for (i in 1:10) 
{
  assign(paste('Y', i, sep=''), HCHO_Monthly[85:127,39:57,i,])
}
yall = cbind(Y1,Y2,Y3,Y4,Y5,Y6,Y7,Y8,Y9,Y10)
boxplot(yall, varwidth = TRUE, xlab = "Years", ylab='HCHO(molec/cm^2)')

#TEMPERATURE PLOT
graphics.off()
for (i in 1:10) 
{
  assign(paste('Y', i, sep=''), TS_Monthly[85:127,39:57,i,])
}
yall = cbind(Y1,Y2,Y3,Y4,Y5,Y6,Y7,Y8,Y9,Y10)
boxplot(yall, varwidth = TRUE, xlab = "Years", ylab='TEMPERATURE IN K')


add_legend <- function(...) {
  opar <- par(fig=c(0, 1, 0, 1), oma=c(0, 0, 0, 0), 
              mar=c(0, 0, 0, 0), new=TRUE)
  on.exit(par(opar))
  plot(0, 0, type='n', bty='n', xaxt='n', yaxt='n')
  legend(...)
}
par(mar = c(5, 4, 1.4, 0.2))
plot(rnorm(50), rnorm(50), col=c("steelblue", "indianred"), pch=20)

add_legend("topright", legend=c("Foo", "Bar"), pch=20, 
           col=c("steelblue", "indianred"),
           horiz=TRUE, bty='n', cex=0.8)

# START OF PROGRAM
#==========================================================
#boxplot using the ggplot
install.packages("ggplot")
library(ggplot) # need to install for the ggplot function
install.packages("reshape2")
library(reshape2) # need to install and library for the melt function

#looping for 10 year
for (i in 1:10) 
{
  #initial year is 2004
  a = 2004; 
  
  # assigning to Y2005, Y2006 and so forth
  assign(paste('Y', a+i, sep=''), HCHO_Monthly[85:127,39:57,i,])
  
}
#column binding
yall = cbind(Y2005,Y2006,Y2007,Y2008,Y2009,Y2010,Y2011,Y2012,Y2013,Y2014)

#melting to get values in only one column
long <- melt(yall)

#assigning the column name
colnames(long) <- c("sn","year","hcho.values")

#finally doing the ggplot
p <- ggplot(long, aes(x=year, y=hcho.values, fill=year)) + 
geom_boxplot()+theme(legend.position="bottom", legend.box = "horizontal") +
labs(title = "Box Plot of Us-SE - HCHO concentration from 2005 - 2014", x = "Years", y = "HCHO(molec/cm^2)") +
stat_summary(fun.y = "mean", geom = "point", shape = 9, size = 1, color = "white")

#setting the path before saving
setwd("D:/R-Programming/sujanojha/test/r-codes/boxplot/")
png("boxplot.png")
print(p)
dev.off()
# END OF PROGRAM


ggplot(data.frame(yall), varwidth = TRUE,
        xlab="Years",
        ylab='HCHO(molec/cm^2)',
       aes(x="", y=data.frame(yall))
)


a = data.frame(HCHO_Monthly[85:127,39:57,1,])
b = data.frame(group = "TEMP", value = TS_Monthly[85:127,39:57,1,])


plot.data = rbind(a, b) # this function will bind or join the rows. See data at bottom.

ggplot(a, aes(x=1:10, y=a)) + geom_boxplot()      # This is the geom for box plot in ggplot.

#yall.df <- as.data.frame(t(yall))
boxplot(yall, varwidth = TRUE,
        xlab="Years",
        ylab='HCHO(molec/cm^2)'
)

o.nrow = dim(HCHO_Monthly[85:127,39:57,1,])[1]
o.ncol = dim(HCHO_Monthly[85:127,39:57,1,])[2]
y[0] = matrix(0, nrow = o.nrow, ncol = o.ncol)
y[0]
for (i in 2:10){
  for (j in 1:5){
    
    a = rbind(a,HCHO_Monthly[85:127,39:57,i,j])
    print(paste( "year - ", i, " month - ", j, dim(HCHO_Monthly[85:127,39:57,i,j])))
    
}
}
a = rbind(a ,HCHO_Monthly[85:127,39:57,1,1])

dim(a)
summary(a)
dim(HCHO_Monthly[85:127,39:57,1,1])

dim(HCHO_Monthly[85:127,39:57,1,])

dev.off()

#layout(mat = matrix(c(1,1,2,2,3,3,4,4,5,5,6,6), nrow = 3, byrow = TRUE))
par(mfrow=c(3,2))
for ( value in 1:10 )  
{
  
  #using the plot funtion we are plotting the 2005 - 2014
  
  # first.qu1 = summary(HCHO_Monthly[85:127,39:57,value,])["1st Qu."]
  # mean1 = summary(HCHO_Monthly[85:127,39:57,value,])["Mean"]
  # third.qu1 = summary(HCHO_Monthly[85:127,39:57,value,])["3rd Qu."]
  # 
  # first.qu2 = substr(summary(TS_Monthly[85:127,39:57,value,])["1st Qu."], 1,5)
  # mean2 = substr(summary(TS_Monthly[85:127,39:57,value,])["Mean"],1,5)
  # third.qu2 = substr(summary(TS_Monthly[85:127,39:57,value,])["3rd Qu."],1,5)
  
  new.matrix = new.matrix + dim(HCHO_Monthly[85:127,39:57,value,])
  
  boxplot(
    HCHO_Monthly[85:127,39:57,value,],  
    type='p',
    ylab = 'HCHo con. (molec/cm^2)'
  )
  
  legend(
    "topleft",
    legend = c(
      paste("1stQ.: ", scientific(first.qu1, digits = 3)),
      paste("Mean : ", scientific(mean1, digits = 3)),
      paste("3rdQ.: ", scientific(third.qu1, digits = 3))
    ),
    bty = 'n',
    cex = 1.5,
    ncol = 1,
    y.intersp=0.7
  )
  #in place of long if else condition
  if (value == 1) {a = 2005}
  if (value == 2) {a = 2006}
  if (value == 3) {a = 2007}
  if (value == 4) {a = 2008}
  if (value == 5) {a = 2009}
  if (value == 6) {a = 2010}
  if (value == 7) {a = 2011}
  if (value == 8) {a = 2012}
  if (value == 9) {a = 2013}
  if (value == 10) {a = 2014}
  
  title(a)
  
  boxplot(
    TS_Monthly[85:127,39:57,value,],  
    type='p',
    ylab = 'Temp. for SE US data'
  )
  
  legend(
    "topleft",
    legend = c(
      paste("1st Q: ", first.qu2),
      paste("Mean : ", mean2),
      paste("3rd Q: ", third.qu2)
    ),
    bty = 'n',
    cex = 1.5,
    ncol = 1,
    y.intersp=0.7
  )
  
  # Add regression line; can also add vertical and horizontal lines by setting 'v' and 'h'
  abline(slr)
  
  #in place of long if else condition
  if (value == 1) {a = 2005}
  if (value == 2) {a = 2006}
  if (value == 3) {a = 2007}
  if (value == 4) {a = 2008}
  if (value == 5) {a = 2009}
  if (value == 6) {a = 2010}
  if (value == 7) {a = 2011}
  if (value == 8) {a = 2012}
  if (value == 9) {a = 2013}
  if (value == 10) {a = 2014}
  
  #finally title of the plot
  title(a)
  
  #turning off the print device
  #dev.off()
}


