install.packages('R2', dependencies=TRUE, repos='http://cran.rstudio.com/')
install.packages("R2")

library(R2)
library(broom)
library(tidyverse)
library(caret)
library(magrittr)
library(modelr)

assign(paste('x',  sep=''),melt(TS_Monthly[85:127,39:57,2,]))
assign(paste('y',  sep=''),melt(HCHO_Monthly[85:127,39:57,2,]))
Data <- data.frame(x, y)
# Load the data
train.data  <- Data
test.data <- Data[sample(nrow(Data), 350), ]
ggplot(train.data, aes(train.data$value, train.data$value.1) ) +
geom_point() +
stat_smooth()

assign(paste('x',  sep=''),melt(TS_Monthly[85:127,39:57,2,]))
assign(paste('y',  sep=''),melt(HCHO_Monthly[85:127,39:57,2,]))
Data <- data.frame(x, y)
# Load the data
train.data  <- Data
test.data <- Data[sample(nrow(Data), 350), ]
ggplot(train.data, aes(train.data$value, train.data$value.1) ) +
  geom_point() +
  stat_smooth()

############################################################
##Linear regression {linear-reg}
############################################################
# Build the model
model <- lm(train.data$value.1 ~ train.data$value, data = train.data)
summary(model)
# Make predictions
predictions <- model %>% predict(test.data)
# Model performance
data.frame(
  RMSE = rmse(predictions, train.data$value.1),
  R2 = r2(predictions, train.data$value.1)
)


Data %>%
  add_predictions(model) %>%
  summarise(
    R2 = cor(train.data$value, predictions)^2,
    MSE = mean((train.data$value - predictions)^2),
    RMSE = sqrt(MSE),
    MAE = mean(abs(train.data$value - predictions))
  )

ggplot(train.data, aes(lstat, medv) ) +
  geom_point() +
  stat_smooth(method = lm, formula = y ~ x)

##Polynomial regression
lm(train.data$value.1 ~ train.data$value + I(train.data$value^2), data = train.data)
lm(train.data$value.1 ~ poly(train.data$value, 2, raw = TRUE), data = train.data)
lm(train.data$value.1 ~ poly(train.data$value, 6, raw = TRUE), data = train.data) %>%
  summary()

# Build the model
model <- lm(train.data$value.1 ~ poly(train.data$value, 5, raw = TRUE), data = train.data)
# Make predictions
predictions <- model %>% predict(test.data)
# Model performance

summary(model)

Data %>%
  add_predictions(model) %>%
  summarise(
    R2 = cor(train.data$value, predictions)^2,
    MSE = mean((train.data$value - predictions)^2),
    RMSE = sqrt(MSE),
    MAE = mean(abs(train.data$value - predictions))
  )
"auto", "lm", "glm", "gam", "loess"

ggplot(train.data, aes(train.data$value, train.data$value.1) ) +
  geom_point(cex = 0.1) +
  stat_smooth(method = lm, formula = y ~ poly(x, 2, raw = TRUE))+
  labs(
    title = "Scatter Plot of Us-SE", 
    subtitle = "HCHO con. v/s Temp [K]",
    x = "Temperature",
    y = "HCHO(molec/cm^2)")

?stat_smooth()

train.data$value.1 ~ train.data$value

###################################################################
#######Log transformation
##################################################################
# Build the model
model <- lm(medv ~ log(lstat), data = train.data)
# Make predictions
predictions <- model %>% predict(test.data)
# Model performance
data.frame(
  RMSE = RMSE(predictions, test.data$medv),
  R2 = R2(predictions, test.data$medv)
)
ggplot(train.data, aes(lstat, medv) ) +
  geom_point() +
  stat_smooth(method = lm, formula = y ~ log(x))


######################
###Spline regression
#####################
knots <- quantile(train.data$lstat, p = c(0.25, 0.5, 0.75))

library(splines)
# Build the model
knots <- quantile(train.data$lstat, p = c(0.25, 0.5, 0.75))
model <- lm (medv ~ bs(lstat, knots = knots), data = train.data)
# Make predictions
predictions <- model %>% predict(test.data)
# Model performance
data.frame(
  RMSE = RMSE(predictions, test.data$medv),
  R2 = R2(predictions, test.data$medv)
)

ggplot(train.data, aes(lstat, medv) ) +
  geom_point() +
  stat_smooth(method = lm, formula = y ~ splines::bs(x, df = 3))

######################################
###Generalized additive models
######################################

library(mgcv)
# Build the model
model <- gam(medv ~ s(lstat), data = train.data)
# Make predictions
predictions <- model %>% predict(test.data)
# Model performance
data.frame(
  RMSE = RMSE(predictions, test.data$medv),
  R2 = R2(predictions, test.data$medv)
)
ggplot(train.data, aes(lstat, medv) ) +
  geom_point() +
  stat_smooth(method = gam, formula = y ~ s(x))
