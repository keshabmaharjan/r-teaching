#setting the working directory to the required path
#install.packages("scales")
#library(scales)
#setwd("D:/R-Programming/sujanojha/test/")

#code to generate the simple linear regression plots yearly basis between HCHO_MONTHLY and TS_MONTHLY
c = 1:10
r_year = 2004
for ( value in c )  
{
  #simple linear regression calculation
  slr = lm(HCHO_Monthly[85:127,39:57,value,] ~ TS_Monthly[85:127,39:57,value,]) # Regressing HCHO = beta0 + beta1*TS
  #simple linear regression coefficients
  sc = summary(slr)$coefficients[2,1]
  #simple linear regression : adjusted r squared values
  ars = summary(slr)$adj.r.squared
  
  #for output in the png format
  png(paste("HCHO_SCATTERPLOT_",value,".png"))
  
  #using the plot funtion we are plotting the 2005 - 2014 
  plot(
    TS_Monthly[85:127,39:57,value,], 
    HCHO_Monthly[85:127,39:57,value,], 
    type='p', 
    xlab='Surface Temperature (K)', 
    ylab='HCHO concentration (molec/cm^2)'
  )  
  
  #place holder for the legend
  legend(
    "topleft", 
    inset=.01,
    legend =c(paste("Slope : ", scientific(sc, digits = 5))), 
    ncol = 1, 
    cex = 1,
    box.lty=0
  )
  
  # Add regression line; can also add vertical and horizontal lines by setting 'v' and 'h'
  abline(slr)
  
  #in place of long if else condition
  if (value == 1) {value = 2005}
  if (value == 2) {value = 2006}
  if (value == 3) {value = 2007}
  if (value == 4) {value = 2008}
  if (value == 5) {value = 2009}
  if (value == 6) {value = 2010}
  if (value == 7) {value = 2011}
  if (value == 8) {value = 2012}
  if (value == 9) {value = 2013}
  if (value == 10) {value = 2014}
  
  #finally title of the plot
  title(paste("HCHO vs Surface Temp. for SE US data - ", value))

  #turning off the print device
  dev.off()
}

#box plot started

#code to generate the simple linear regression plots yearly basis between HCHO_MONTHLY and TS_MONTHLY
c = 1:10
r_year = 2004
for ( value in c )  
{
  #simple linear regression calculation
  slr = lm(HCHO_Monthly[85:127,39:57,value,] ~ TS_Monthly[85:127,39:57,value,]) # Regressing HCHO = beta0 + beta1*TS
  #simple linear regression coefficients
  sc = summary(slr)$coefficients[2,1]
  #simple linear regression : adjusted r squared values
  ars = summary(slr)$adj.r.squared
  
  #for output in the png format
  png(paste("HCHP_BOXPLOT_CONCENTRATION_",value,".png"))
  
  #using the plot funtion we are plotting the 2005 - 2014 
  boxplot(
    HCHO_Monthly[85:127,39:57,value,], 
    ylab='HCHO concentration (molec/cm^2)'
  )  
  
  #place holder for the legend
  legend(
    "topleft", 
    inset=.01,
    legend =c(paste("Coefficients : ", scientific(sc, digits = 5)), paste("Adj.r.squared : ", scientific(ars, digits = 5))), 
    ncol = 1, 
    cex = 1,
    box.lty=0
  )
  
  #in place of long if else condition
  if (value == 1) {value = 2005}
  if (value == 2) {value = 2006}
  if (value == 3) {value = 2007}
  if (value == 4) {value = 2008}
  if (value == 5) {value = 2009}
  if (value == 6) {value = 2010}
  if (value == 7) {value = 2011}
  if (value == 8) {value = 2012}
  if (value == 9) {value = 2013}
  if (value == 10) {value = 2014}
  
  #finally title of the plot
  title(paste("HCHO vs Surface Temp. for SE US data - ", value))
  
  #turning off the print device
  dev.off()
}

# box plot for the temperature
c = 1:10
r_year = 2004
for ( value in c )  
{
  #simple linear regression calculation
  slr = lm(HCHO_Monthly[85:127,39:57,value,] ~ TS_Monthly[85:127,39:57,value,]) # Regressing HCHO = beta0 + beta1*TS
  #simple linear regression coefficients
  sc = summary(slr)$coefficients[2,1]
  #simple linear regression : adjusted r squared values
  ars = summary(slr)$adj.r.squared
  
  #for output in the png format
  png(paste("HCHP_BOXPLOT_TEMP_",value,".png"))
  
  #using the plot funtion we are plotting the 2005 - 2014 
  boxplot(
    TS_Monthly[85:127,39:57,value,], 
    ylab='Surface Temperature (K)'
  )  
  
  #place holder for the legend
  legend(
    "topleft", 
    inset=.01,
    legend =c(paste("Coefficients : ", scientific(sc, digits = 5)), paste("Adj.r.squared : ", scientific(ars, digits = 5))), 
    ncol = 1, 
    cex = 1,
    box.lty=0
  )
  
  #in place of long if else condition
  if (value == 1) {value = 2005}
  if (value == 2) {value = 2006}
  if (value == 3) {value = 2007}
  if (value == 4) {value = 2008}
  if (value == 5) {value = 2009}
  if (value == 6) {value = 2010}
  if (value == 7) {value = 2011}
  if (value == 8) {value = 2012}
  if (value == 9) {value = 2013}
  if (value == 10) {value = 2014}
  
  #finally title of the plot
  title(paste("HCHO vs Surface Temp. for SE US data - ", value))
  
  #turning off the print device
  dev.off()
}



##TEST
par(mfrow=c(2,2))
c = 1:10
for ( value in c )  
{
  #using the plot funtion we are plotting the 2005 - 2014 
  boxplot(
    HCHO_Monthly[85:127,39:57,value,], 
    ylab='HCHO concentration (molec/cm^2)'
  ) 
  
  boxplot(
    TS_Monthly[85:127,39:57,value,], 
    ylab='Surface Temperature (K)'
  ) 

 
  #finally title of the plot
  title(paste("HCHO vs Surface Temp. for SE US data - ", value))
  
  #turning off the print device
  dev.off()
}



