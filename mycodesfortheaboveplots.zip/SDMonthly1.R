# SD for differenr months

SDMay=sd(HCHO_Monthly[85:127,39:58,,1],na.rm = TRUE); SDMay
SDJune=sd(HCHO_Monthly[85:127,39:58,,2],na.rm = TRUE); SDJune
SDJuly=sd(HCHO_Monthly[85:127,39:58,,3],na.rm = TRUE); SDJuly
SDAug=sd(HCHO_Monthly[85:127,39:58,,4],na.rm = TRUE); SDAug
SDSep=sd(HCHO_Monthly[85:127,39:58,,2],na.rm = TRUE); SDSep
