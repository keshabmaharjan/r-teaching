# 2005 to 2014 Avg for 5 months with bold mean line at the center.


SE1=HCHO_Monthly[85:127,39:58,,]; 
SEOAvY=apply(SE1, 3, mean, na.rm=TRUE);SEOAvY

May1=HCHO_Monthly[85:127,39:58,,1]; AvMay1=apply(May1, 3, mean, na.rm=TRUE);AvMay1
June1=HCHO_Monthly[85:127,39:58,,2]; AvJune1=apply(June1, 3, mean, na.rm=TRUE);AvJune1
July1=HCHO_Monthly[85:127,39:58,,3]; AvJuly1=apply(July1, 3, mean, na.rm=TRUE);AvJuly1
Aug1=HCHO_Monthly[85:127,39:58,,4]; AvAug1=apply(Aug1, 3, mean, na.rm=TRUE);AvAug1
Sep1=HCHO_Monthly[85:127,39:58,,5]; AvSep1=apply(Sep1, 3, mean, na.rm=TRUE);AvSep1


RMaytoSep = range(c(SEOAvY,AvMay1,AvJune1,AvJuly1,AvAug1,AvSep1), na.rm=TRUE);RMaytoSep
plot(Year, AvMay1, type='l',lwd = 2, col='violet', xlab='Years(2005-2014)'
     , ylab='HCHO(mol/cm^2)', ylim=RMaytoSep) ;
matplot(Year, AvJune1, type='l',lwd = 2, col='black', add=TRUE);
matplot(Year, AvJuly1, type='l', lwd = 2,col='green', add=TRUE);
matplot(Year, AvAug1, type='l',lwd = 2, col='yellow', add=TRUE);
matplot(Year, AvSep1, type='l', lwd = 2,col='red', add=TRUE);
matplot(Year, SEOAvY, type='l', lwd = 6,col='darkblue', add=TRUE);
title("Regional Avg over SE US",cex.main = 1.5,font.main= 4, col.main= "blue")
legend("topright", legend =c('Mean','May','June','July','Aug.','Sep.'),
       col =c('darkblue','violet','black','green','yellow','red'),
       ncol = 1, cex = 0.8, lwd = 4)



