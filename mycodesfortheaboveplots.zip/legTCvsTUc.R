# legend


legend("topright", legend =c('Tem. Uncorrected', 'Tem. Corrected'), col =c('blue','red'),  ncol = 1, cex = 1, lwd = 3)