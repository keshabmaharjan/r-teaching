# Mean for different years

Mean05=mean(HCHO_Monthly[85:127,39:58,1,],na.rm = TRUE); Mean05
Mean06=mean(HCHO_Monthly[85:127,39:58,2,],na.rm = TRUE); Mean06
Mean07=mean(HCHO_Monthly[85:127,39:58,3,],na.rm = TRUE); Mean07
Mean08=mean(HCHO_Monthly[85:127,39:58,4,],na.rm = TRUE); Mean08
Mean09=mean(HCHO_Monthly[85:127,39:58,5,],na.rm = TRUE); Mean09
Mean10=mean(HCHO_Monthly[85:127,39:58,6,],na.rm = TRUE); Mean10
Mean11=mean(HCHO_Monthly[85:127,39:58,7,],na.rm = TRUE); Mean11
Mean12=mean(HCHO_Monthly[85:127,39:58,8,],na.rm = TRUE); Mean12
Mean13=mean(HCHO_Monthly[85:127,39:58,9,],na.rm = TRUE); Mean13
Mean14=mean(HCHO_Monthly[85:127,39:58,10,],na.rm = TRUE); Mean14
