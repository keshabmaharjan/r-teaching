y05=HCHO_Monthly[85:127,39:58,1,]; AvY05=apply(y05, 3, mean, na.rm=TRUE);AvY05
