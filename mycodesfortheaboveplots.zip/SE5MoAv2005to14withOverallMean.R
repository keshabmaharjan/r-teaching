# 5 MONTHS SE Avg for 2005- 2014 with bold mean line at the center.


SE1=HCHO_Monthly[85:127,39:58,,]; 
SEOAvMo=apply(SE1, 4, mean, na.rm=TRUE);SEOAvMo

y05=HCHO_Monthly[85:127,39:58,1,]; AvY05=apply(y05, 3, mean, na.rm=TRUE);AvY05
y06=HCHO_Monthly[85:127,39:58,2,]; AvY06=apply(y06, 3, mean, na.rm=TRUE);AvY06
y07=HCHO_Monthly[85:127,39:58,3,]; AvY07=apply(y07, 3, mean, na.rm=TRUE);AvY07
y08=HCHO_Monthly[85:127,39:58,4,]; AvY08=apply(y08, 3, mean, na.rm=TRUE);AvY08
y09=HCHO_Monthly[85:127,39:58,5,]; AvY09=apply(y09, 3, mean, na.rm=TRUE);AvY09
y10=HCHO_Monthly[85:127,39:58,6,]; AvY10=apply(y10, 3, mean, na.rm=TRUE);AvY10
y11=HCHO_Monthly[85:127,39:58,7,]; AvY11=apply(y11, 3, mean, na.rm=TRUE);AvY11
y12=HCHO_Monthly[85:127,39:58,8,]; AvY12=apply(y12, 3, mean, na.rm=TRUE);AvY12
y13=HCHO_Monthly[85:127,39:58,9,]; AvY13=apply(y13, 3, mean, na.rm=TRUE);AvY13
y14=HCHO_Monthly[85:127,39:58,10,];AvY14=apply(y14, 3, mean, na.rm=TRUE);AvY14

R05to14 = range(c(SEOAvMo,AvY05,AvY06,AvY07,AvY08,AvY09,AvY10,AvY11,AvY12,AvY13,AvY14), na.rm=TRUE);R05to14
plot(Month, AvY05, type='l',lwd = 2, col='violet', xlab='Months(May-Sept)'
     , ylab='HCHO(mol/cm^2)', ylim=R05to14) ;
matplot(Month, AvY06, type='l', lwd = 2,col='blue', add=TRUE);
matplot(Month, AvY07, type='l',lwd = 2, col='green', add=TRUE);
matplot(Month, AvY08, type='l',lwd = 2, col='yellow', add=TRUE);
matplot(Month, AvY09, type='l', lwd = 2,col='orange', add=TRUE);
matplot(Month, AvY10, type='l', lwd = 2,col='red', add=TRUE);
matplot(Month, AvY11, type='l', lwd = 2,col='black', add=TRUE);
matplot(Month, AvY12, type='l', lwd = 2,col='gray', add=TRUE);
matplot(Month, AvY13, type='l', lwd = 2,col='brown', add=TRUE);
matplot(Month, AvY14, type='l', lwd = 2,col='pink', add=TRUE);
matplot(Month, SEOAvMo, type='l', lwd = 6,col='darkblue', add=TRUE);
title("Regional avg over SE US",cex.main = 1.5,font.main= 4, col.main= "blue")
legend("topleft", legend =c('Mean','2005','2006','2007','2008','2009','2010','2011','2012','2013','2014'),
       col =c('darkblue','violet','blue','green','yellow','orange','red','black','gray','brown','pink'),
       ncol = 2, cex = 0.8, lwd = 4)



