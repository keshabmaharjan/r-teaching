#SD Yearly of five months mean data


y05=HCHO_Monthly[85:127,39:58,1,]; AvY05=apply(y05, 3, mean, na.rm=TRUE);AvY05
y06=HCHO_Monthly[85:127,39:58,2,]; AvY06=apply(y06, 3, mean, na.rm=TRUE);AvY06
y07=HCHO_Monthly[85:127,39:58,3,]; AvY07=apply(y07, 3, mean, na.rm=TRUE);AvY07
y08=HCHO_Monthly[85:127,39:58,4,]; AvY08=apply(y08, 3, mean, na.rm=TRUE);AvY08
y09=HCHO_Monthly[85:127,39:58,5,]; AvY09=apply(y09, 3, mean, na.rm=TRUE);AvY09
y10=HCHO_Monthly[85:127,39:58,6,]; AvY10=apply(y10, 3, mean, na.rm=TRUE);AvY10
y11=HCHO_Monthly[85:127,39:58,7,]; AvY11=apply(y11, 3, mean, na.rm=TRUE);AvY11
y12=HCHO_Monthly[85:127,39:58,8,]; AvY12=apply(y12, 3, mean, na.rm=TRUE);AvY12
y13=HCHO_Monthly[85:127,39:58,9,]; AvY13=apply(y13, 3, mean, na.rm=TRUE);AvY13
y14=HCHO_Monthly[85:127,39:58,10,];AvY14=apply(y14, 3, mean, na.rm=TRUE);AvY14
SD05=sd(AvY05,na.rm = TRUE); SD05
SD06=sd(AvY06,na.rm = TRUE); SD06
SD07=sd(AvY07,na.rm = TRUE); SD07
SD08=sd(AvY08,na.rm = TRUE); SD08
SD09=sd(AvY09,na.rm = TRUE); SD09
SD10=sd(AvY10,na.rm = TRUE); SD10
SD11=sd(AvY11,na.rm = TRUE); SD11
SD12=sd(AvY12,na.rm = TRUE); SD12
SD13=sd(AvY13,na.rm = TRUE); SD13
SD14=sd(AvY14,na.rm = TRUE); SD14

