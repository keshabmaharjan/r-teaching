#5 months regional avg for differenet years


y10=HCHO_Monthly[85:127,39:58,6,]; AvY10=apply(y10, 3, mean, na.rm=TRUE);AvY10
[1] 7.423756e+15 1.051991e+16 1.038133e+16 1.189062e+16 7.714022e+15
> y11=HCHO_Monthly[85:127,39:58,7,]; AvY11=apply(y11, 3, mean, na.rm=TRUE);AvY11
[1] 6.597145e+15 9.911838e+15 1.310689e+16 1.173971e+16 7.386490e+15
> y12=HCHO_Monthly[85:127,39:58,8,]; AvY12=apply(y12, 3, mean, na.rm=TRUE);AvY12
[1] 7.600932e+15 9.993770e+15 1.182066e+16 9.413794e+15 6.980155e+15
> y13=HCHO_Monthly[85:127,39:58,9,]; AvY13=apply(y13, 3, mean, na.rm=TRUE);AvY13
[1] 6.663771e+15 7.989930e+15 9.176825e+15 9.186040e+15 7.662838e+15
> y14=HCHO_Monthly[85:127,39:58,10,]; AvY14=apply(y14, 3, mean, na.rm=TRUE);AvY14
[1] 6.954916e+15 9.463488e+15 9.347730e+15 9.707090e+15 7.173623e+15
> plot(Month, AvY10, type='b', col='blue', xlab='Months(May-Sept)', 
       ylab='HCHO(mol/cm^2)',ylim=R10to14) ;
matplot(Month, AvY11, type='b', col='green', add=TRUE);
matplot(Month, AvY12, type='b', col='yellow', add=TRUE);
matplot(Month, AvY13, type='b', col='black', add=TRUE);
matplot(Month, AvY14, type='b', col='red', add=TRUE);
title("(Tem. Uncorrected) Avg over SE US from 2010 t0 14",
      cex.main = 1.5,   font.main= 4, col.main= "green");
legend("topright", legend =c('2010','2011','2012','2013','2014'), col =c('blue','green','yellow','black','red'),  ncol = 1, cex = 1, lwd = 3)