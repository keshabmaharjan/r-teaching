#legend for 10 years

legend("topright", legend =c('2005','2006','2007','2008','2009','2010','2011','2012','2013','2014'),
       col =c('violet','blue','green','yellow','orange','red','black','gray','brown','pink'),  ncol = 1, cex = 1, lwd = 3)
