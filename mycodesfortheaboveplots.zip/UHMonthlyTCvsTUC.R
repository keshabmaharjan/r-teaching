

UHTUc2010=HCHO_Monthly[90,39,6,];UHTUc2010
UHTc2010=HCHO_corrected_Monthly[90,39,6,];UHTc2010
RUH2010=range(UHTc2010,UHTUc2010);RUH2010
plot(Month, UHTUc2010, type='b', col='blue', xlab='Months(May-Sept)',ylab='HCHO(mol/cm^2)',ylim=RUH2010) ;matplot(Month, UHTc2010, type='b', col='red', add=TRUE);title("HCHO monthly mean data for UH",cex.main = 1.5,   font.main= 4, col.main= "green");legend("topleft", legend =c('Tem. Uncorrected', 'Tem. Corrected'), col =c('blue','red'),  ncol = 1, cex = 1, lwd = 3)
