#using looping methods
par(mfrow=c(5,5))
d = 1:5
c = 1:5

for (year in d)
{
  for (month in c)
  {
    image.plot(Lon, Lat, HCHO_Monthly[,,year,month])
    map('world', add=TRUE)
  }
}


par(mfrow=c(5,5))
d = 6:10
c = 1:5
for (year in d)
{
  for (month in c)
  {
    image.plot(Lon, Lat, HCHO_Monthly[,,year,month])
    map('world', add=TRUE)
  }
}