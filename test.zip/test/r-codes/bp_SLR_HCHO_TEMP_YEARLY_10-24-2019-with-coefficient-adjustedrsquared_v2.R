#setting the working directory to the required path
#install.packages("scales")
#library(scales)
#setwd("D:/R-Programming/sujanojha/test/")
#getwd()
#code to generate the simple linear regression plots yearly basis between HCHO_MONTHLY and TS_MONTHLY

#dev.off()

#layout(mat = matrix(c(1,1,2,2,3,3,4,4,5,5,6,6), nrow = 3, byrow = TRUE))
par(mfrow=c(3,2))
c = 1:6
for ( value in c )  
{
  #simple linear regression calculation
  slr = lm(HCHO_Monthly[85:127,39:57,value,] ~ TS_Monthly[85:127,39:57,value,]) # Regressing HCHO = beta0 + beta1*TS
  #simple linear regression coefficients
  sc = summary(slr)$coefficients[2,1]
  #simple linear regression : adjusted r squared values
  ars = summary(slr)$adj.r.squared
  
  #for output in the png format
  #png(paste("HCHO_SCATTERPLOT_",value,".png"))
  
  #using the plot funtion we are plotting the 2005 - 2014 
  min = summary(HCHO_Monthly[85:127,39:57,value,])["Min."]
  first.qu = summary(HCHO_Monthly[85:127,39:57,value,])["1st Qu."]
  median = summary(HCHO_Monthly[85:127,39:57,value,])["Median"]
  mean = summary(HCHO_Monthly[85:127,39:57,value,])["Mean"]
  
  min = summary(TS_Monthly[85:127,39:57,value,])["Min."]
  first.qu = summary(TS_Monthly[85:127,39:57,value,])["1st Qu."]
  median = summary(TS_Monthly[85:127,39:57,value,])["Median"]
  mean = summary(TS_Monthly[85:127,39:57,value,])["Mean"]
  
  boxplot(
    HCHO_Monthly[85:127,39:57,1,],  
    type='p'
  ) 
  
  legend(
    "topleft",
    legend = c(paste("Slope : ", scientific(sc, digits = 5)),paste("Min. : ", scientific(min, digits = 5)),
               paste("1st Qu. : ", scientific(first.qu, digits = 5)),paste("Median : ", scientific(median, digits = 5)),
               paste("Mean : ", scientific(mean, digits = 5))
               ),
    bty = 'n',
    cex = 1,
    ncol = 1,
    y.intersp=0.5
  )
  #in place of long if else condition
  if (value == 1) {a = 2005}
  if (value == 2) {a = 2006}
  if (value == 3) {a = 2007}
  if (value == 4) {a = 2008}
  if (value == 5) {a = 2009}
  if (value == 6) {a = 2010}
  if (value == 7) {a = 2011}
  if (value == 8) {a = 2012}
  if (value == 9) {a = 2013}
  if (value == 10) {a = 2014}
  
  title(paste("HCHO concentration (molec/cm^2) - ", a))
  
  boxplot(
    TS_Monthly[85:127,39:57,value,],
    type='p'
  ) 
  
  legend(
    "topleft",
    legend = c(paste("Slope : ", scientific(sc, digits = 5)),paste("Min. : ", scientific(min, digits = 5)),
               paste("1st Qu. : ", scientific(first.qu, digits = 5)),paste("Median : ", scientific(median, digits = 5)),
               paste("Mean : ", scientific(mean, digits = 5))
    ),
    bty = 'n',
    cex = 1,
    ncol = 1,
    y.intersp=0.5
  )
  
  # Add regression line; can also add vertical and horizontal lines by setting 'v' and 'h'
  abline(slr)
  
  #in place of long if else condition
  if (value == 1) {a = 2005}
  if (value == 2) {a = 2006}
  if (value == 3) {a = 2007}
  if (value == 4) {a = 2008}
  if (value == 5) {a = 2009}
  if (value == 6) {a = 2010}
  if (value == 7) {a = 2011}
  if (value == 8) {a = 2012}
  if (value == 9) {a = 2013}
  if (value == 10) {a = 2014}
  
  #finally title of the plot
  title(paste("Temp. for SE US data - ", a))
  
  #turning off the print device
  #dev.off()
}


#setting the working directory to the required path
#install.packages("scales")
#library(scales)
#setwd("D:/R-Programming/sujanojha/test/")
#getwd()
#code to generate the simple linear regression plots yearly basis between HCHO_MONTHLY and TS_MONTHLY

#dev.off()

layout(mat = matrix(c(1,1,2,2,3,3,0,4,4,5,5,0), nrow = 2, byrow = TRUE))
c = 6:10
for ( value in c )  
{
  #simple linear regression calculation
  slr = lm(HCHO_Monthly[85:127,39:57,value,] ~ TS_Monthly[85:127,39:57,value,]) # Regressing HCHO = beta0 + beta1*TS
  #simple linear regression coefficients
  sc = summary(slr)$coefficients[2,1]
  #simple linear regression : adjusted r squared values
  ars = summary(slr)$adj.r.squared
  
  #for output in the png format
  #png(paste("HCHO_SCATTERPLOT_",value,".png"))
  
  #using the plot funtion we are plotting the 2005 - 2014 
  
  boxplot(
    TS_Monthly[85:127,39:57,value,], 
    HCHO_Monthly[85:127,39:57,value,], 
    type='p', 
    xlab='Surface Temperature (K)', 
    ylab='HCHO concentration (molec/cm^2)'
  ) 
  
  
  legend(
    "topleft",
    legend =c(paste("Slope:", scientific(sc, digits = 5))),
    bty = 'n',
    cex = 1.2
    
  )
  
  # Add regression line; can also add vertical and horizontal lines by setting 'v' and 'h'
  abline(slr)
  
  #in place of long if else condition
  if (value == 1) {a = 2005}
  if (value == 2) {a = 2006}
  if (value == 3) {a = 2007}
  if (value == 4) {a = 2008}
  if (value == 5) {a = 2009}
  if (value == 6) {a = 2010}
  if (value == 7) {a = 2011}
  if (value == 8) {a = 2012}
  if (value == 9) {a = 2013}
  if (value == 10) {a = 2014}
  
  #finally title of the plot
  title(paste("HCHO vs Surface Temp. for SE US data - ", a))
  
  #turning off the print device
  #dev.off()
}



