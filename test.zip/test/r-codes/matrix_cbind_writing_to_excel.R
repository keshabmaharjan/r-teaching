#for the writing in excel we must install these
install.packages("xlsxjars")
library(xlsxjars)
library("xlsx")

#Monthly hcho and Temperature data of the SE for the year 2005 and month of May
HCHO_Monthly_SE = HCHO_Monthly[85:127,39:57,1,1]
TS_Monthly_SE = TS_Monthly[85:127,39:57,1,1]

#combining the hcho concentration and monthly temperature with the help of the cbind function
HCHO_MONTHLY_COMBINE_SE <- cbind(HCHO_Monthly_SE, TS_Monthly_SE)

dfcmb <- cbind(Lat, Lon, HCHO_MONTHLY_COMBINE_SE)

#writing to the excel for the combined matrix
write.xlsx(dfcmb, file = "dfcmb.xlsx",sheetName = "dfcmb", append = FALSE)

# own
