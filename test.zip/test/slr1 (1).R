#Simple linear regression:

c = 1:10
for ( value in c )  
{
  png(paste("boxplot_",value,".png"))
  geom_boxplot(outlier.colour="black", outlier.shape=16,
               outlier.size=2, notch=FALSE)
  boxplot(TS_Monthly[85:127,39:57,value,], HCHO_Monthly[85:127,39:57,value,], type='p', xlab='Surface temperature (K)', ylab='HCHO concentration (molec/cm^2)')
  if (value == 1) {value = 2005}
  if (value == 2) {value = 2006}
  if (value == 3) {value = 2007}
  if (value == 4) {value = 2008}
  if (value == 5) {value = 2009}
  if (value == 6) {value = 2010}
  if (value == 7) {value = 2011}
  if (value == 8) {value = 2012}
  if (value == 9) {value = 2013}
  if (value == 10) {value = 2014}
  title(paste("HCHO vs Surface Temp. for SE US data - ", value))
  dev.off()
}


#Simple linear regression:

c = 1:10
for ( value in c )  
{
  png(paste("boxplot_",value,".png"))
  geom_boxplot(outlier.colour="black", outlier.shape=16,
               outlier.size=2, notch=FALSE)
  boxplot(TS_Monthly[85:127,39:57,value,], HCHO_Monthly[85:127,39:57,value,], type='p', xlab='Surface temperature (K)', ylab='HCHO concentration (molec/cm^2)')
  if (value == 1) {value = 2005}
  if (value == 2) {value = 2006}
  if (value == 3) {value = 2007}
  if (value == 4) {value = 2008}
  if (value == 5) {value = 2009}
  if (value == 6) {value = 2010}
  if (value == 7) {value = 2011}
  if (value == 8) {value = 2012}
  if (value == 9) {value = 2013}
  if (value == 10) {value = 2014}
  title(paste("HCHO vs Surface Temp. for SE US data - ", value))
  dev.off()
}

dfcmb

ggplot(dfcmb, aes(x = 1:5, y = dfcmb)) +
  geom_boxplot()

------------------------------------------------------
c = 1:10
for ( value in c )  
{
  slr = lm(HCHO_Monthly[85:127,39:57,value,] ~ TS_Monthly[85:127,39:57,value,]) # Regressing HCHO = beta0 + beta1*TS
  png(paste("slr",value,".png"))
  plot(TS_Monthly[85:127,39:57,value,], HCHO_Monthly[85:127,39:57,value,], type='p', xlab='Surface temperature (K)', ylab='HCHO concentration (molec/cm^2)')
  abline(slr) # Add regression line; can also add vertical and horizontal lines by setting 'v' and 'h'
  if (value == 1) {value = 2005}
  if (value == 2) {value = 2006}
  if (value == 3) {value = 2007}
  if (value == 4) {value = 2008}
  if (value == 5) {value = 2009}
  if (value == 6) {value = 2010}
  if (value == 7) {value = 2011}
  if (value == 8) {value = 2012}
  if (value == 9) {value = 2013}
  if (value == 10) {value = 2014}
  title(paste("HCHO vs Surface Temp. for SE US data - ", value))
  dev.off()
}
--------------------------------------------------------------
  
  
  