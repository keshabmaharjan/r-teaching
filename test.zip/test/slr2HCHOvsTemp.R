#Simple linear regression:

slr1 = lm(HCHO_Monthly[85:127,39:57,6,1]~ TS_Monthly[85:127,39:57,6,1])		# Regressing HCHO = beta0 + beta1*TS
summary(slr)	# Get summary statistics
plot(TS_Monthly, HCHO_Monthly, type='p', xlab='Surface temperature (K)', ylab='HCHO concentration (molec/cm^2)')
abline(slr)		# Add regression line; can also add vertical and horizontal lines by setting 'v' and 'h'
title('HCHO vs Surface Temp.')