#Simple linear regression:


HCHO_Monthly_SE = HCHO_Monthly[85:127,39:57,1,2]

TS_Monthly_SE = TS_Monthly[85:127,39:57,1,2] 

  slr2 = lm(HCHO_Monthly_SE ~ TS_Monthly_SE)		# Regressing HCHO = beta0 + beta1*TS
  summary(slr2)	# Get summary statistics
  plot(TS_Monthly_SE, HCHO_Monthly_SE, type='p', xlab='Surface temperature (K)', ylab='HCHO concentration (molec/cm^2)')
  abline(slr2)		# Add regression line; can also add vertical and horizontal lines by setting 'v' and 'h'
  title('HCHO vs Surface Temp. for SE US data')
  
  HCHO_Monthly_SE = HCHO_Monthly[85:127,39:57,1,2]
  
  TS_Monthly_SE = TS_Monthly[85:127,39:57,1,2] 
  
  slr2 = lm(HCHO_Monthly_SE ~ TS_Monthly_SE)		# Regressing HCHO = beta0 + beta1*TS
  summary(slr2)	# Get summary statistics
  plot(TS_Monthly_SE, HCHO_Monthly_SE, type='p', xlab='Surface temperature (K)', ylab='HCHO concentration (molec/cm^2)')
  abline(slr2)		# Add regression line; can also add vertical and horizontal lines by setting 'v' and 'h'
  title('HCHO vs Surface Temp. for SE US data')