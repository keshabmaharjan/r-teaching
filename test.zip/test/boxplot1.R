#Boxplot

boxplot(HCHO_Monthly~ TS_Monthly, col = "lightgray")